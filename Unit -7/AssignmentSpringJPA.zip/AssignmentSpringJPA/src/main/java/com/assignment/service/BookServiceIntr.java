package com.assignment.service;

public interface BookServiceIntr {

}
