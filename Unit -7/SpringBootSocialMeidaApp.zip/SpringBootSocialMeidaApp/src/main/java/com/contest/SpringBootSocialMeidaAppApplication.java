package com.contest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSocialMeidaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSocialMeidaAppApplication.class, args);
	}

}
