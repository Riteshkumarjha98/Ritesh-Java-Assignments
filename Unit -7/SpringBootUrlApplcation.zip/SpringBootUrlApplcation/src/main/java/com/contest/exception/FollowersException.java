package com.contest.exception;

public class FollowersException extends RuntimeException {
	
	public FollowersException() {
		
	}
	
	  public FollowersException( String message) {
			super(message);
		}

}
