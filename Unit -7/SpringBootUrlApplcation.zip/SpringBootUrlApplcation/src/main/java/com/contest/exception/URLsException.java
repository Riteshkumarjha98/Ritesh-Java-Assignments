package com.contest.exception;

public class URLsException extends RuntimeException {
	
	public URLsException() {
		
	}
	
	  public URLsException( String message) {
			super(message);
		}

}
