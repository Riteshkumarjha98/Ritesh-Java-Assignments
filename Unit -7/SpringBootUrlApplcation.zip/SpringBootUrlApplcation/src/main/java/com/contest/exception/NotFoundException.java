package com.contest.exception;

public class NotFoundException extends Exception {
	
	public NotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public NotFoundException(String msg) {
		super(msg);
	}
	
	

}
